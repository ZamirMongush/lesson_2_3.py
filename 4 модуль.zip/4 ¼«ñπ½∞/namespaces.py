import math


def square(x):
    d = x ** 2
    return d


a = 5
b = square(2)
print(a)
print(b)
print(globals())



